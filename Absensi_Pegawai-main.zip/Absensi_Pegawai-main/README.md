# Absensi_Pegawai
Sebuah percobaan aplikasi web untuk melakukan absen pegawai

Untuk menggunakannya
1. Masukkan file ini semua di folder htdocs kalian masing masing
2. import file sql yang ada disini ke database kalian
3. Untuk login, lihat note yang disediakan (userlogin.txt)
